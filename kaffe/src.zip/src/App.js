import './App.css';
import CoffeeList from './components/coffees/CoffeeList';

function App() {
  return (
    <div className="App">
      <CoffeeList/>
    </div>
  );
}

export default App;
