import CoffeeItem from "./CoffeeItem";

const CoffeeList = () => {

    const coffeeArray = [
        { name: "Blue Java", roastLevel: "Lightly", pricePerKg: 200 },
        { name: "Geisha", roastLevel: "Roasted", pricePerKg: 200 },
        { name: "Tropical", roastLevel: "Strongly", pricePerKg: 200 }
    ];

    const createCoffeeList = () => {
        const coffees = coffeeArray.map( coffee => {
            return <CoffeeItem name={coffee.name} roastLevel={coffee.roastLevel}/>    
        }  )
        return coffees;
    }

    return (
        <section>
            <header>
                <h3>Kaffer</h3>
            </header>
            <section>
                { createCoffeeList() }
            </section>
        </section>
    )
}

export default CoffeeList;